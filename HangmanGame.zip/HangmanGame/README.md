# Hangman – JavaFX Game

A fully playable Hangman game built with JavaFX. Features a dark theme, animated letter buttons, keyboard support, hints, difficulty levels, and a live scoreboard.

---

## Project Structure

```
HangmanGame/
├── src/
│   └── hangman/
│       ├── Main.java              ← App entry point
│       ├── GameController.java    ← FXML controller + all game UI logic
│       ├── HangmanDrawing.java    ← Canvas drawing (gallows + stick figure)
│       ├── WordManager.java       ← Word bank, guessing logic, difficulty
│       └── views/
│           ├── game.fxml          ← Scene Builder UI layout
│           └── style.css          ← Dark theme stylesheet
└── README.md
```

---

## How to Run

### Option 1 – IntelliJ IDEA (Recommended)

1. Open IntelliJ → **File > New > Project from Existing Sources** → select the `HangmanGame` folder
2. Set up JavaFX:
   - Download JavaFX SDK from https://gluonhq.com/products/javafx/
   - Go to **File > Project Structure > Libraries** → Add the JavaFX `lib` folder
3. Edit your run configuration:
   - Main class: `hangman.Main`
   - VM options:
     ```
     --module-path /path/to/javafx-sdk/lib --add-modules javafx.controls,javafx.fxml
     ```
4. Hit **Run**!

### Option 2 – Maven

Add these to your `pom.xml`:

```xml
<dependency>
    <groupId>org.openjfx</groupId>
    <artifactId>javafx-controls</artifactId>
    <version>21</version>
</dependency>
<dependency>
    <groupId>org.openjfx</groupId>
    <artifactId>javafx-fxml</artifactId>
    <version>21</version>
</dependency>
```

Then run with the JavaFX Maven plugin.

---

## How to Play

- **Click a letter button** or **press a key on your keyboard** to guess
- You have **6 mistakes** before the hangman is complete
- Click **💡 Hint** to reveal a random letter (costs a guess)
- Click **New Game** to restart anytime
- Change **difficulty** to Easy / Medium / Hard for different word lengths

---

## Features

| Feature | Details |
|---|---|
| Hangman drawing | Canvas-based, draws each body part per mistake |
| Keyboard input | Press any A-Z key to guess instantly |
| Letter buttons | Green = correct, Red = wrong, disabled after guessing |
| Win/loss detection | Auto-detects with animated status messages |
| Hint system | Reveals a random unguessed letter |
| Difficulty | Easy (3-letter), Medium (6-letter), Hard (12-letter words) |
| Scoreboard | Tracks wins, losses, win rate live |
| Dark theme | Full CSS dark theme with smooth hover effects |

---

## Extending the Project

Ideas to add next:
- Save high scores to a file using `ObjectOutputStream`
- Add a timer countdown per guess
- Add sound effects with `AudioClip`
- Load words from an external `words.txt` file
- Add a category selector (animals, programming, countries)
- Animate the hangman drawing with `Timeline`
